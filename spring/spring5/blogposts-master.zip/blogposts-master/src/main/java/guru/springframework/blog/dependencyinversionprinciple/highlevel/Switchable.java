package guru.springframework.blog.dependencyinversionprinciple.highlevel;

public interface Switchable {
    void turnOn();
    void turnOff();
}
