package guru.springframework.blog.interfacesegregationprinciple;

public interface Movable {
    void move();
}
