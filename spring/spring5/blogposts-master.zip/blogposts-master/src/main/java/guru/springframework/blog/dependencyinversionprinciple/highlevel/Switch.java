package guru.springframework.blog.dependencyinversionprinciple.highlevel;

public interface Switch {
    boolean isOn();
    void press();
}
