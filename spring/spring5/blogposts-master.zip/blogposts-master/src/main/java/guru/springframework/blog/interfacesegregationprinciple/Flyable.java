package guru.springframework.blog.interfacesegregationprinciple;

public interface Flyable {
    void fly();
}
