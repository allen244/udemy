package guru.springframework.blog.interfacesegregationprinciple;

public interface Toy {
     void setPrice(double price);
     void setColor(String color);
}
